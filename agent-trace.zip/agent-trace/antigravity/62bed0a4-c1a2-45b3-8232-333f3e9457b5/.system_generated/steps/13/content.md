Title: GitHub - interviewstreet/hackerrank-orchestrate-october26 · GitHub

Description: Contribute to interviewstreet/hackerrank-orchestrate-october26 development by creating an account on GitHub.

Source: https://github.com/interviewstreet/hackerrank-orchestrate-october26

---

[Skip to content](https://github.com/interviewstreet/hackerrank-orchestrate-october26#start-of-content)

[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Finterviewstreet%2Fhackerrank-orchestrate-october26)
- PlatformAI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryIntegrate external tools](https://github.com/mcp)DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)[Code QualityEnforce quality at merge](https://github.com/features/code-quality)APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)[View all features](https://github.com/features)
- AI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryIntegrate external tools](https://github.com/mcp)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryIntegrate external tools](https://github.com/mcp)
- DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)[Code QualityEnforce quality at merge](https://github.com/features/code-quality)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
- [Code QualityEnforce quality at merge](https://github.com/features/code-quality)
- APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)

- SolutionsBY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[See all industries](https://github.com/solutions/industry)[View all solutions](https://github.com/solutions)
- BY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)
- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
- BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
- BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[See all industries](https://github.com/solutions/industry)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [See all industries](https://github.com/solutions/industry)
- ResourcesEXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)[View all resources](https://github.com/resources)
- EXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)

- EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
- SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)
- Open SourceCOMMUNITY[GitHub SponsorsFund open source developers](https://github.com/open-source/sponsors)PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- COMMUNITY[GitHub SponsorsFund open source developers](https://github.com/open-source/sponsors)
- [GitHub SponsorsFund open source developers](https://github.com/open-source/sponsors)
- PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
- REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
- EnterpriseENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/enterprise/premium-support)
- ENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/enterprise/premium-support)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/enterprise/premium-support)
- [Pricing](https://github.com/pricing)
- AI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryIntegrate external tools](https://github.com/mcp)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryIntegrate external tools](https://github.com/mcp)

- DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)[Code QualityEnforce quality at merge](https://github.com/features/code-quality)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
- [Code QualityEnforce quality at merge](https://github.com/features/code-quality)
- APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryIntegrate external tools](https://github.com/mcp)
[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
[MCP RegistryIntegrate external tools](https://github.com/mcp)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
- [Code QualityEnforce quality at merge](https://github.com/features/code-quality)
[ActionsAutomate any workflow](https://github.com/features/actions)
[CodespacesInstant dev environments](https://github.com/features/codespaces)
[IssuesPlan and track work](https://github.com/features/issues)
[Code ReviewManage code changes](https://github.com/features/code-review)
[Code QualityEnforce quality at merge](https://github.com/features/code-quality)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
[Why GitHub](https://github.com/why-github)
[Documentation](https://docs.github.com)
[Blog](https://github.blog)
[Changelog](https://github.blog/changelog)
[Marketplace](https://github.com/marketplace)
[View all features](https://github.com/features)
- BY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)

- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
- BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
- BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[See all industries](https://github.com/solutions/industry)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [See all industries](https://github.com/solutions/industry)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)
- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
[Enterprises](https://github.com/enterprise)
[Small and medium teams](https://github.com/team)
[Startups](https://github.com/enterprise/startups)
[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
[App Modernization](https://github.com/solutions/use-case/app-modernization)
[DevSecOps](https://github.com/solutions/use-case/devsecops)
[DevOps](https://github.com/solutions/use-case/devops)
[CI/CD](https://github.com/solutions/use-case/ci-cd)
[View all use cases](https://github.com/solutions/use-case)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [See all industries](https://github.com/solutions/industry)
[Healthcare](https://github.com/solutions/industry/healthcare)
[Financial services](https://github.com/solutions/industry/financial-services)
[Manufacturing](https://github.com/solutions/industry/manufacturing)
[Government](https://github.com/solutions/industry/government)
[See all industries](https://github.com/solutions/industry)
[View all solutions](https://github.com/solutions)
- EXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
- EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)

- SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
[AI](https://github.com/resources/articles?topic=ai)
[Software Development](https://github.com/resources/articles?topic=software-development)
[DevOps](https://github.com/resources/articles?topic=devops)
[Security](https://github.com/resources/articles?topic=security)
[View all topics](https://github.com/resources/articles)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
[Customer stories](https://github.com/customer-stories)
[Events & webinars](https://github.com/resources/events)
[Ebooks & reports](https://github.com/resources/whitepapers)
[Business insights](https://github.com/solutions/executive-insights)
[GitHub Skills](https://skills.github.com)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)
[Documentation](https://docs.github.com)
[Customer support](https://support.github.com)
[Community forum](https://github.com/orgs/community/discussions)
[Trust center](https://github.com/trust-center)
[Partners](https://github.com/partners)
[View all resources](https://github.com/resources)
- COMMUNITY[GitHub SponsorsFund open source developers](https://github.com/open-source/sponsors)
- [GitHub SponsorsFund open source developers](https://github.com/open-source/sponsors)
- PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
- REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
- [GitHub SponsorsFund open source developers](https://github.com/open-source/sponsors)
[GitHub SponsorsFund open source developers](https://github.com/open-source/sponsors)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
[Security Lab](https://securitylab.github.com)
[Maintainer Community](https://maintainers.github.com)
[GitHub Stars](https://stars.github.com)
[Archive Program](https://archiveprogram.github.com)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
[Topics](https://github.com/topics)
[Trending](https://github.com/trending)
[Collections](https://github.com/collections)
- ENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/enterprise/premium-support)

## Navigation Menu
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/enterprise/premium-support)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/enterprise/premium-support)
[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
[Premium SupportEnterprise-grade 24/7 support](https://github.com/enterprise/premium-support)
[Pricing](https://github.com/pricing)
[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Finterviewstreet%2Fhackerrank-orchestrate-october26)
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=header+logged+out&ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E&source=header-repo&source_repo=interviewstreet%2Fhackerrank-orchestrate-october26)
[Reload](https://github.com/interviewstreet/hackerrank-orchestrate-october26)
[Reload](https://github.com/interviewstreet/hackerrank-orchestrate-october26)
[Reload](https://github.com/interviewstreet/hackerrank-orchestrate-october26)
1. [interviewstreet](https://github.com/interviewstreet)
2. [hackerrank-orchestrate-october26](https://github.com/interviewstreet/hackerrank-orchestrate-october26)
[interviewstreet](https://github.com/interviewstreet)
[hackerrank-orchestrate-october26](https://github.com/interviewstreet/hackerrank-orchestrate-october26)

## Repository navigation
- 
- [Code](https://github.com/interviewstreet/hackerrank-orchestrate-october26)
- [Issues4 (4)](https://github.com/interviewstreet/hackerrank-orchestrate-october26/issues)
- [Pull requests7 (7)](https://github.com/interviewstreet/hackerrank-orchestrate-october26/pulls)
- [Actions](https://github.com/interviewstreet/hackerrank-orchestrate-october26/actions)
- [Security and quality](https://github.com/interviewstreet/hackerrank-orchestrate-october26/security)
- [Insights](https://github.com/interviewstreet/hackerrank-orchestrate-october26/pulse)
[Code](https://github.com/interviewstreet/hackerrank-orchestrate-october26)
[Issues4 (4)](https://github.com/interviewstreet/hackerrank-orchestrate-october26/issues)
[Pull requests7 (7)](https://github.com/interviewstreet/hackerrank-orchestrate-october26/pulls)
[Actions](https://github.com/interviewstreet/hackerrank-orchestrate-october26/actions)
[Security and quality](https://github.com/interviewstreet/hackerrank-orchestrate-october26/security)
[Insights](https://github.com/interviewstreet/hackerrank-orchestrate-october26/pulse)
[hackerrank-orchestrate-october26](https://github.com/interviewstreet/hackerrank-orchestrate-october26)
- [Notifications](https://github.com/login?return_to=%2Finterviewstreet%2Fhackerrank-orchestrate-october26)You must be signed in to change notification settings
- [Fork494 (494)](https://github.com/login?return_to=%2Finterviewstreet%2Fhackerrank-orchestrate-october26)
- [Star124 (124)](https://github.com/login?return_to=%2Finterviewstreet%2Fhackerrank-orchestrate-october26)You must be signed in to star a repository
[Notifications](https://github.com/login?return_to=%2Finterviewstreet%2Fhackerrank-orchestrate-october26)
[Fork494 (494)](https://github.com/login?return_to=%2Finterviewstreet%2Fhackerrank-orchestrate-october26)
[Star124 (124)](https://github.com/login?return_to=%2Finterviewstreet%2Fhackerrank-orchestrate-october26)

### Resources
[Readme](https://github.com/interviewstreet/hackerrank-orchestrate-october26#readme-ov-file)
[Activity](https://github.com/interviewstreet/hackerrank-orchestrate-october26/activity)
[Custom properties](https://github.com/interviewstreet/hackerrank-orchestrate-october26/custom-properties)

### Forks
[494 forks](https://github.com/interviewstreet/hackerrank-orchestrate-october26/forks)
[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Finterviewstreet%2Fhackerrank-orchestrate-october26&report=interviewstreet+%28user%29)
[Branches](https://github.com/interviewstreet/hackerrank-orchestrate-october26/branches)
[Tags](https://github.com/interviewstreet/hackerrank-orchestrate-october26/tags)

## History
[42 Commits](https://github.com/interviewstreet/hackerrank-orchestrate-october26/commits/main/)

## Folders and files
[code](https://github.com/interviewstreet/hackerrank-orchestrate-october26/tree/main/code)
[code](https://github.com/interviewstreet/hackerrank-orchestrate-october26/tree/main/code)
[dataset](https://github.com/interviewstreet/hackerrank-orchestrate-october26/tree/main/dataset)
[dataset](https://github.com/interviewstreet/hackerrank-orchestrate-october26/tree/main/dataset)
[AGENTS.md](https://github.com/interviewstreet/hackerrank-orchestrate-october26/blob/main/AGENTS.md)
[AGENTS.md](https://github.com/interviewstreet/hackerrank-orchestrate-october26/blob/main/AGENTS.md)
[CLAUDE.md](https://github.com/interviewstreet/hackerrank-orchestrate-october26/blob/main/CLAUDE.md)
[CLAUDE.md](https://github.com/interviewstreet/hackerrank-orchestrate-october26/blob/main/CLAUDE.md)
[README.md](https://github.com/interviewstreet/hackerrank-orchestrate-october26/blob/main/README.md)
[README.md](https://github.com/interviewstreet/hackerrank-orchestrate-october26/blob/main/README.md)
[agent_trace_instructions.md](https://github.com/interviewstreet/hackerrank-orchestrate-october26/blob/main/agent_trace_instructions.md)
[agent_trace_instructions.md](https://github.com/interviewstreet/hackerrank-orchestrate-october26/blob/main/agent_trace_instructions.md)
[problem_statement.md](https://github.com/interviewstreet/hackerrank-orchestrate-october26/blob/main/problem_statement.md)
[problem_statement.md](https://github.com/interviewstreet/hackerrank-orchestrate-october26/blob/main/problem_statement.md)

## Repository files navigation
- 
- [README](https://github.com/interviewstreet/hackerrank-orchestrate-october26)
[README](https://github.com/interviewstreet/hackerrank-orchestrate-october26)

## Ghost Data Still Exists
Build an AI agent that audits whether a user's personal data was actually deleted.
A deletion workflow may report Complete while data still exists in databases, logs, support attachments, exports, search indexes, archives, or backups. Sync and restore processes may also bring deleted data back.
For each request, the agent must first determine whether deletion was actually requested. It then returns COMPLETE, INCOMPLETE, or NOT_APPLICABLE, reports any remaining data or recreation risk, and produces the ordered remediation and verification steps required to finish an authorized deletion safely.

```
COMPLETE
```


```
INCOMPLETE
```


```
NOT_APPLICABLE
```

Read [problem_statement.md](https://github.com/interviewstreet/hackerrank-orchestrate-october26/blob/main/problem_statement.md) for the complete challenge contract.

```
problem_statement.md
```

## Quick Start
Clone the repository and move into the project directory:

```
git clone https://github.com/interviewstreet/hackerrank-orchestrate-october26.git cd hackerrank-orchestrate-october26
```

Start your AI coding tool from the repository root so it automatically reads [AGENTS.md](https://github.com/interviewstreet/hackerrank-orchestrate-october26/blob/main/AGENTS.md) and logs your session turns to log.txt in the root directory.

```
AGENTS.md
```


```
log.txt
```

Build your solution in code/main.py, or use another language and document its setup and run command clearly in your README.

```
code/main.py
```

Your solution must:
- Read the input files from dataset/
- Generate one prediction row for every request in dataset/deletion_requests.csv
- Write the final predictions to output.csv in the repository root

```
dataset/
```


```
dataset/deletion_requests.csv
```


```
output.csv
```

Run the starter Python entry point with:

```
python3 code/main.py
```

The blank template at dataset/output.csv is provided as a reference. Your final generated file for submission must be the root-level output.csv.

```
dataset/output.csv
```


```
output.csv
```

## Dataset
All participant-facing files are in dataset/:

```
dataset/
```


```
deletion_requests.csv
```


```
sample_deletion_requests.csv
```


```
sample_output.csv
```


```
user_identities.csv
```


```
user_audit_log.csv
```


```
system_activity.csv
```


```
deletion_rules.csv
```


```
evidence_files.csv
```


```
output.csv
```

Evidence is stored under dataset/evidence/ and may include PDFs, images, logs, JSON, plain text, or SQL snapshot exports. SQL captures may contain a primary database, regional replicas, a reporting replica, or a failover replica so replication drift can be investigated directly. The .sql files are readable as text and executable with SQLite.

```
dataset/evidence/
```


```
.sql
```

Only deletion_requests.csv requires answers. The other files provide evidence and context.

```
deletion_requests.csv
```

## Output
Create output.csv with these columns in this exact order:

```
output.csv
```


```
case_id,deletion_status,steps_json
```


```
case_id,deletion_status,steps_json
```

Produce exactly one row per request. deletion_status is COMPLETE, INCOMPLETE, or NOT_APPLICABLE. steps_json is an ordered JSON array containing findings, remediation actions, and verification checks. Use an empty array ([]) for NOT_APPLICABLE. Evidence references may be a file_id, activity_id, or audit_id. Determine the resource state at audit_at from the available evidence; reported workflow statuses and operation results are claims. Use dataset/sample_output.csv as the format reference.

```
deletion_status
```


```
COMPLETE
```


```
INCOMPLETE
```


```
NOT_APPLICABLE
```


```
steps_json
```


```
[]
```


```
NOT_APPLICABLE
```


```
file_id
```


```
activity_id
```


```
audit_id
```


```
audit_at
```


```
dataset/sample_output.csv
```

The final file must contain 518 data rows sorted by case_id (plus the header row). The grader parses steps_json as JSON, so object-key order and whitespace do not matter; array order does. Order findings, remediation, and verification in that phase order. Within a phase, follow the operation order in the problem statement, then sort by system_id and resource_id.

```
case_id
```


```
steps_json
```


```
system_id
```


```
resource_id
```

## Evaluation
output.csv will be compared with hidden canonical answers. Scoring considers:

```
output.csv
```

- deletion assessment accuracy;
- current and historical identity resolution;
- discovery of remaining data and recreation risks;
- correct policy application and evidence references; and
- completeness and ordering of remediation and verification steps.
Your code.zip must include:

```
code.zip
```


```
code/evaluation/evaluation_report.md code/evaluation/usage_report.md
```


```
code/evaluation/evaluation_report.md code/evaluation/usage_report.md
```

- evaluation_report.md must cover case, row, field, and sequence accuracy, at least three additional evaluation cases created by you, failures found, and improvements made.
- usage_report.md must cover the final full-dataset run, including model providers and names, model calls, input and output tokens, total and average tokens per request, and estimated total and per-request cost. Include per-model and overall totals when using multiple models.

```
evaluation_report.md
```


```
usage_report.md
```

Important: Place evaluation_report.md and usage_report.md inside code/evaluation/ (matching code/evaluation/main.py in this starter layout), write your complete evaluation metrics, custom evaluation test cases, and token/cost breakdowns directly inside those Markdown files, and keep prompts in source code or Markdown files. Automated code evaluation ignores raw data files (.csv, .tsv, .json, .jsonl, .sql, .log), so content stored only in those formats will not be visible to the code judge or AI interviewer.

```
evaluation_report.md
```


```
usage_report.md
```


```
code/evaluation/
```


```
code/evaluation/main.py
```


```
.csv
```


```
.tsv
```


```
.json
```


```
.jsonl
```


```
.sql
```


```
.log
```

## Chat Transcript
This repository includes [AGENTS.md](https://github.com/interviewstreet/hackerrank-orchestrate-october26/blob/main/AGENTS.md), which instructs compatible AI coding tools to append conversation summaries to log.txt in the repository root:

```
AGENTS.md
```


```
log.txt
```


```
<repo root>/log.txt
```


```
<repo root>\log.txt
```

- Always launch your AI coding agent from the repository root (or explicitly ask it to read ./AGENTS.md first) so every turn is logged to log.txt with the required User Prompt, Agent Response Summary, Actions, and Context sections.
- Upload log.txt directly as your chat_transcript submission on HackerRank.
- Do not include API keys, tokens, credentials, or secrets in prompts, code, configuration, or log.txt.

```
./AGENTS.md
```


```
log.txt
```


```
User Prompt
```


```
Agent Response Summary
```


```
Actions
```


```
Context
```


```
log.txt
```


```
chat_transcript
```


```
log.txt
```

```
code.zip
```


```
code.zip
```


```
README.md
```


```
evaluation/
```


```
output.csv
```


```
dataset/deletion_requests.csv
```


```
chat_transcript
```


```
log.txt
```

You may use any programming language, model, framework, or retrieval approach. Include clear setup and execution instructions in README.md inside code.zip.

```
README.md
```


```
code.zip
```

To package code.zip from the repository root without bundling the dataset:

```
code.zip
```

macOS / Linux:

```
zip -r code.zip README.md code -x "*/__pycache__/*" "*/.venv/*" "*/venv/*" "*/node_modules/*" "*/.git/*" "*/.DS_Store"
```

Windows (PowerShell):

```
Compress-Archive -Path README.md, code -DestinationPath code.zip -Force
```

When packaging code.zip:

```
code.zip
```

- Keep your evaluation reports in code/evaluation/ so they are bundled automatically with code (or add evaluation to the archive command above if you placed them in a top-level evaluation/ directory).
- Do not include dataset/, virtual environments (.venv, venv, node_modules), or build caches (__pycache__). On Windows, keep .venv at the repository root (outside code/) and remove any code/__pycache__ folders before running Compress-Archive.
- Do not include nested archives (.zip, .tar, .gz, .tgz, .7z, .rar) inside code.zip — submissions containing nested archive files will be rejected.

```
code/evaluation/
```


```
code
```


```
evaluation
```


```
evaluation/
```


```
dataset/
```


```
.venv
```


```
venv
```


```
node_modules
```


```
__pycache__
```


```
.venv
```


```
code/
```


```
code/__pycache__
```


```
Compress-Archive
```


```
.zip
```


```
.tar
```


```
.gz
```


```
.tgz
```


```
.7z
```


```
.rar
```


```
code.zip
```

Before submitting, confirm that:
- output.csv has the exact header case_id,deletion_status,steps_json and contains all 518 data rows sorted by case_id;
- every steps_json value is a valid JSON array with consecutive step numbers starting at 1;
- findings cite valid evidence IDs, and COMPLETE verification steps cite evidence proving the current state;
- proposed remediation and future verification steps use an empty evidence_id ("");
- code.zip includes your runnable code, README.md, code/evaluation/evaluation_report.md, and code/evaluation/usage_report.md;
- log.txt follows the AGENTS.md turn format and is uploaded to the chat_transcript slot; and
- no API keys, credentials, real personal data, or sensitive configuration values are included.

```
output.csv
```


```
case_id,deletion_status,steps_json
```


```
case_id
```


```
steps_json
```


```
1
```


```
COMPLETE
```


```
evidence_id
```


```
""
```


```
code.zip
```


```
README.md
```


```
code/evaluation/evaluation_report.md
```


```
code/evaluation/usage_report.md
```


```
log.txt
```


```
AGENTS.md
```


```
chat_transcript
```

### Resources
[Readme](https://github.com/interviewstreet/hackerrank-orchestrate-october26#readme-ov-file)
[Activity](https://github.com/interviewstreet/hackerrank-orchestrate-october26/activity)
[Custom properties](https://github.com/interviewstreet/hackerrank-orchestrate-october26/custom-properties)

### Forks
[494 forks](https://github.com/interviewstreet/hackerrank-orchestrate-october26/forks)
[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Finterviewstreet%2Fhackerrank-orchestrate-october26&report=interviewstreet+%28user%29)

- 
            [Terms](https://docs.github.com/site-policy/github-terms/github-terms-of-service)

- 
            [Privacy](https://docs.github.com/site-policy/privacy-policies/github-privacy-statement)

- 
              [Security](https://github.com/security)

- 
              [Status](https://www.githubstatus.com/)

- 
            [Community](https://github.community/)

- 
            [Docs](https://docs.github.com/)

- 
            [Contact](https://support.github.com?tags=dotcom-footer)

- 


      Manage cookies



- 


        Do not share my personal information



[Terms](https://docs.github.com/site-policy/github-terms/github-terms-of-service)
[Privacy](https://docs.github.com/site-policy/privacy-policies/github-privacy-statement)
[Security](https://github.com/security)
[Status](https://www.githubstatus.com/)
[Community](https://github.community/)
[Docs](https://docs.github.com/)
[Contact](https://support.github.com?tags=dotcom-footer)

